# Meta × Embed power package (shift-detect)

```
digest X=[Z_PCA, M]  →  RF/DR power  →  ρ_PO  →  CFPerm block power  →  meta subset
```

## Read first

1. `python/results/unified_meta_power.tex`
2. `python/results/RESULTS.md`
3. `python/results/power_cross_modality_full.md` — CFPerm **block power** by modality

## Run

```bash
cd python
pip install -r requirements.txt && python -m spacy download en_core_web_sm
python -m datasets.biasfinder_gen --n-max 2000
python digest_pipeline.py --scenario sentiment_meta --subset
```

## Logic

| piece | role |
| --- | --- |
| `datasets/*` | per-dataset digestion |
| `extract_features.py` / `extract_mm_features.py` | named meta |
| `feature_schema.py` | block indices |
| `perm_tests.py` | RFPerm / DRPerm / CFPerm |
| `digest_pipeline.py` | ρ_PO + subset |
| `power_cross_modality.py` | CFPerm power per block |

ρ_PO = absorb/residual. CFPerm table = which named block's power is high.
