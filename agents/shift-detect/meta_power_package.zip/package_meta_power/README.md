# shift-detect (simple)

```
digest.py
interactions.py      # PO-risk, MMD, R-risk, power-loss, RF/DR/CF
run_benchmark_all.py # → DataFrame
utils.py
datasets/            # dataset-specific
```

Insight: embedding does not represent everything.
