# shift-detect package (5 scripts)

```
digest.py              # 1. data digestion → Digested
interactions.py        # 2. PO-risk / MMD / R-risk / power-loss / RF·DR·CF
run_benchmark_all.py   # 3. main → DataFrame
utils.py               # 4. shared helpers
subset_localize.py     # 5. ORIGINAL: CFPerm block → driving feature subset
datasets/              # dataset-specific only
```

## Logic

```
datasets/<name>.digest()
        → Digested (X, y, schema)
              ├─ interactions / run_benchmark_all  → power table
              └─ subset_localize                   → feature subset
```

## Run

```bash
cd python
pip install -r requirements.txt
# optional full stack: pip install -r requirements-full.txt && source ./env_full.sh

python digest.py --dataset modasense_emotion --audio --write
python run_benchmark_all.py --dataset modasense_emotion --smoke
python run_benchmark_all.py --dataset modasense_emotion --B 100 --n-perm 150
```

Canonical table: `python/results/joint_shift_analysis.tex`  
Manuscript: `python/results/manuscript_final.tex`  
Insight: embedding does not represent everything.
