# Meta × Embed package

Download: [`meta_power_package.zip`](meta_power_package.zip) (~94KB).

Contents: digestion + perm tests + curated results (`unified_meta_power.tex`, cross-modality CFPerm **block power** tables, ModaSense case).

```
digest X=[Z,M] → RF/DR power → ρ_PO → CFPerm block power → meta subset
```

Live sources also under `python/` (same logic; zip is the snapshot bundle).

## ModaSense scientific case (primary)

Read `python/results/modasense_scientific_case.md`:
RFPerm + CFPerm + MMD modality share + ρ_PO + localization, with explicit
non-claims where evidence does not close (image silent-absorb; audio MMD-only).
