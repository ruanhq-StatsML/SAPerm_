# Meta × Embed package

Download: [`meta_power_package.zip`](meta_power_package.zip).

Contents: digestion + perm tests + curated results (unified tables, ModaSense scientific case).

```
# BiasFinder
digest X=[Z,M] → RF/DR → ρ_PO → CFPerm → meta subset

# ModaSense (primary multimodal)
digest X=[M_text,M_image,M_audio] → RF/CF power → π_MMD → ρ_PO → localization
```

ModaSense digestion logic: `python/docs/modasense_digestion.md`  
Scientific case: `python/results/modasense_scientific_case.md`

Live sources also under `python/` (zip is the snapshot bundle).

## ModaSense digestion (start here for multimodal)

Logic: `python/docs/modasense_digestion.md`

```bash
python -m datasets.modasense_emotion --n-max 500 --audio --write
```

→ `X=[M_text, M_image, M_audio]` + schema; then RF/CF / π_MMD / ρ_PO / localization
(`python/results/modasense_scientific_case.md`).
